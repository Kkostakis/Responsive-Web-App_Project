var express = require('express');
const { generateFromEmail, generateUsername } = require("unique-username-generator");
var app = express();
const path = require('path');
var session = require('express-session');
var bodyParser = require('body-parser');
const { render } = require('ejs');
const { v4: uuidv4 } = require('uuid');
const { request } = require('http');
const unique = uuidv4();
const expressfile = require('multer');
var MongoClient = require("mongodb").MongoClient;
// Server path
var url = 'mongodb://localhost/';

app.listen(8080, function(){console.log("Grand_Server");});
app.use(express.static(__dirname));
app.use('/uploads', express.static('uploads'));
app.set('views',path.join(__dirname,'views'));
app.set("view engine", "ejs");
app.use(bodyParser.urlencoded({ extended:true }));

var storage = expressfile.diskStorage({
    destination: function (req, file, cb) {
      cb(null, './uploads')
    },
    filename: function (req, file, cb) {
      cb(null, file.originalname)
    }
})
var upload = expressfile({ storage: storage });

app.get("/", function(req, res) {
    res.render('login');}
    );

app.get("/redirect_login", function(req, res) {
    res.render('login');}
    );

app.get("/redirect", function(req, res) { 
    res.render('starting_page');
});

app.get("/redirect_register", function(req, res) {
    res.render('register');}
    );

app.get("/redirect_profileprt1", function(req, res) {
    res.render('change_username');}
    );
    
app.get("/redirect_profileprt2", function(req, res) {
    res.render('change_password');}
    );
    
app.get("/redirect_profileprt3", function(req, res) {
    res.render('change_email');}
    );

    app.get("/redirect_edit_prt1", function(req, res) {
        res.render('admin_change_username');}
        );
        
    app.get("/redirect_edit_prt2", function(req, res) {
        res.render('admin_change_password');}
        );
        
    app.get("/redirect_edit_prt3", function(req, res) {
        res.render('admin_change_email');}
        );

    app.get("/redirect_edit_prt4", function(req, res) {
        res.render('admin_change_uuid');}
        );

    app.get("/redirect_edit_prt5", function(req, res) {
        res.render('admin_change_comments');}
        );

    app.get("/redirect_edit_prt6", function(req, res) {
        res.render('admin_remove_user');}
        );

        app.get("/redirect_admin_home", function(req, res) {
            res.render('admin_starting_page');}
            );
    

app.get("/redirect_entertainment", function(req, res) {
    res.render('entertainment');}
    );

app.get("/redirect_monument", function(req, res) {
    res.render('monuments');}
    );

app.get("/redirect_food", function(req, res) {
    res.render('food');}
    );

app.get("/redirect_activities", function(req, res) {
    res.render('activities_page');}
    );

app.get("/redirect_destination", function(req, res) {
    res.render('destination_info');}
    );

app.get("/redirect_adminfood", function(req, res) {
    res.render('admin_food');}
    );

app.get("/redirect_adminmonument", function(req, res) {
    res.render('admin_monuments');}
    );

app.get("/redirect_adminentertainment", function(req, res) {
    res.render('admin_entertainment');}
    );

app.get("/redirect_admin_activities", function(req, res) {
    res.render('edit_activities_page');}
    );

app.get("/redirect_search_act", function(req, res) {
    res.render('search_activities');}
    );

app.get("/redirect_adminlogin", function(req, res) {
    res.render('adminlogin');}
    );

    app.get("/redirect_admin_booking_uuid", function(req, res) {
        res.render('admin_booking_uuid');}
        );

        app.get("/redirect_admin_booking_checkin", function(req, res) {
            res.render('admin_booking_checkin');}
            );
            app.get("/redirect_admin_booking_checkout", function(req, res) {
                res.render('admin_booking_checkout');}
                );
                app.get("/redirect_admin_booking_count", function(req, res) {
                    res.render('admin_booking_count');}
                    );
                    app.get("/redirect_admin_booking_code1", function(req, res) {
                        res.render('admin_booking_code1');}
                        );
                        app.get("/redirect_admin_booking_code2", function(req, res) {
                            res.render('admin_booking_code2');}
                            );
                            app.get("/redirect_admin_booking_code3", function(req, res) {
                                res.render('admin_booking_code3');}
                                );
                                app.get("/redirect_admin_booking_code4", function(req, res) {
                                    res.render('admin_booking_code4');}
                                    );
                                    app.get("/redirect_admin_booking_radio", function(req, res) {
                                        res.render('admin_booking_radio');}
                                        );

                                        app.get("/redirect_admin_booking_wallet", function(req, res) {
                                            res.render('admin_booking_wallet');}
                                            );
                                            app.get("/redirect_admin_booking_randomcode", function(req, res) {
                                                res.render('admin_booking_randomcode');}
                                                );
                                                app.get("/redirect_admin_remove_booking", function(req, res) {
                                                    res.render('admin_remove_booking');}
                                                    );
                                                    app.get("/redirect_admin_booking_days", function(req, res) {
                                                        res.render('admin_booking_days');}
                                                        );

app.get("/redirect_destination_review", function(req, res) {
    res.render('destination_review');}
    );

app.get("/redirect_events", function(req, res) {
    res.render('view_events');}
    );

app.get("/redirect_profile", function(req, res) {
    res.render('view_profile');}
    );

app.get("/redirect_booking", function(req, res) {
    res.render('booking_page');}
    );

app.get("/redirect_edit_events", function(req, res) {
    res.render('edit_events_page');}
    );

app.get("/redirect_edit_booking", function(req, res) {
    res.render('edit_booking_page');}
    );

app.post("/Login", function(req, res) {
    var myusername = req.body.username;
    var mypassword = req.body.password;
    var myemail= req.body.email;


    MongoClient.connect(url, async function(err, db){
    if(err){
        console.log("Mongodb connection was a failure!!!!");throw err;
    }
    else{
        console.log("Successfully connected to Mongodb!!!!");
        var dbo = db.db("Navigators");
        var query = {'Username': myusername, 'Password': mypassword, 'Email': myemail};
        const result = await dbo.collection("Users").findOne(query, {projection: {_id: 0, Username: 1, Password: 1, Email: 1}}); 
        
        dbo.collection("Users").find({'Username': myusername, 'Password': mypassword, 'Email': myemail}).toArray(async function(err1, rows) {
            if(err1){
                console.log("Error!!!!");
                throw err1;
            }
            else{
                
                   if(result)
                   {
                        const updated_uuid = await dbo.collection("Users").updateOne({'Username': myusername, 'Password': mypassword, 'Email': myemail}, { $set: {'uuid': unique} });
                        const updated_uuid2 = await dbo.collection("Booking").insertOne({'uuid': unique, 'Date_In': new Date(), 'Date_Out': new Date(), 'Count': 0, 'Card_Code1': "",  'Card_Code2': "", 'Card_Code3': "", 'Card_Code4': "", 'Days': "", 'Radio': "", 'Wallet': 20000, 'Random_Id': 0});
                        console.log(updated_uuid2);
                        console.log("You have successfully logged in " + "with login_id: " + unique);
                        res.render("starting_page");
    
                    }

                    
                    else
                    {
                        console.log("Invalid credentials!!!!");
                    }  
                   
                    
                }

            db.close();
        }); 
        
        
    }

  });

});

app.get("/redirect_profile", function(req, res) {
    res.render('view_profile');}
    );

app.post("/ViewProfile", function(req, res) {
    var myusername = req.body.username;
    var mypassword = req.body.password;
    var myemail= req.body.email;
    var myuuid = req.body.uuid;

    MongoClient.connect(url, async function(err, db){
    if(err){
        console.log("Mongodb connection was a failure!!!!");throw err;
    }
    else{
        console.log("Successfully connected to Mongodb!!!!");
        var dbo = db.db("Navigators");
        var query = {'Username': myusername, 'Password': mypassword, 'Email': myemail, 'uuid': myuuid};
        const result = await dbo.collection("Users").findOne(query, {projection: {_id: 0, Username: 1, Password: 1, Email: 1, uuid: 1}}); 
        
        dbo.collection("Users").find(query).toArray(async function(err1, rows) {
            if(err1){
                console.log("Error!!!!");
                throw err1;
            }
            else{
                
                   if(result)
                   {
                        console.log("View your account profile!!!!");
                        console.log(rows);
                        res.render("view_profile2", {'Username': myusername, 'Password': mypassword, 'Email': myemail, 'uuid': myuuid});
                        
                    }
                    else
                    {
                        console.log("This user does not exist or has not logged in!!!!");
                    }  
                   
                    
                }

            db.close();
        }); 
        
        
    }

  });

});

app.get("/", function(req, res) {
    res.render('change_username');});
app.post("/ChangeUsername", function(req, res) {
    var uuid = req.body.uuid;
    var current_username = req.body.username;
    var new_username = req.body.new_username;

    MongoClient.connect(url, async function(err, db){
    if(err){
        console.log("Mongodb connection was a failure!!!!");throw err;
    }
    else{
        console.log("Successfully connected to Mongodb!!!!");
        var dbo = db.db("Navigators");
        var query = {'Username': current_username, 'uuid': uuid};
        const result = await dbo.collection("Users").findOne(query, {projection: {_id: 0, Username: 1, Password: 1, Email: 1, uuid: 1}}); 
        
        dbo.collection("Users").find(query).toArray(async function(err1, rows) {
            if(err1){
                console.log("Error!!!!");
                throw err1;
            }
            else{
                
                   if(result)
                   {
                        const updated_user = await dbo.collection("Users").updateOne({'Username': current_username},  { $set: {'Username': new_username} });
                        const result1 = await dbo.collection("Users").findOne({'Username': new_username}, {projection: {_id: 0, Username: 1, Password: 1, Email: 1, uuid: 1}}); 
                        console.log("Change your account username!!!!");
                        console.log(result1);

                        res.render("view_profile");
                    }
                    else
                    {
                        console.log("This user does not exist or has not logged in!!!!");
                    }  
                   
                    
                }

            db.close();
        }); 
        
        
    }

  });

});

app.get("/", function(req, res) {
    res.render('change_password');});
app.post("/ChangePassword", function(req, res) {
    var uuid = req.body.uuid;
    var current_password = req.body.password;
    var new_password = req.body.new_password;
   

    MongoClient.connect(url, async function(err, db){
    if(err){
        console.log("Mongodb connection was a failure!!!!");throw err;
    }
    else{
        console.log("Successfully connected to Mongodb!!!!");
        var dbo = db.db("Navigators");
        var query = {'Password': current_password, 'uuid': uuid};
        const result = await dbo.collection("Users").findOne(query, {projection: {_id: 0, Username: 1, Password: 1, Email: 1, uuid: 1}}); 
        
        dbo.collection("Users").find(query).toArray(async function(err1, rows) {
            if(err1){
                console.log("Error!!!!");
                throw err1;
            }
            else{
                
                   if(result)
                   {
                        const updated_pass = await dbo.collection("Users").updateOne({'Password': current_password}, { $set: {'Password': new_password} });
                        console.log("Change your account password!!!!");
                        const result1 = await dbo.collection("Users").findOne({'Password': new_password}, {projection: {_id: 0, Username: 1, Password: 1, Email: 1, uuid: 1}}); 
                        console.log(result1);

                        res.render("view_profile");
                    }
                    else
                    {
                        console.log("This user does not exist or has not logged in!!!!");
                    }  
                   
                    
                }

            db.close();
        }); 
        
        
    }

  });

});

app.get("/", function(req, res) {
    res.render('change_email');});
app.post("/ChangeEmail", function(req, res) {
    var uuid = req.body.uuid;
    var current_email = req.body.email;
    var new_email = req.body.new_email;

    MongoClient.connect(url, async function(err, db){
    if(err){
        console.log("Mongodb connection was a failure!!!!");throw err;
    }
    else{
        console.log("Successfully connected to Mongodb!!!!");
        var dbo = db.db("Navigators");
        var query = {'Email': current_email, 'uuid': uuid};
        const result = await dbo.collection("Users").findOne(query, {projection: {_id: 0, Username: 1, Password: 1, Email: 1, uuid: 1}}); 
        
        dbo.collection("Users").find(query).toArray(async function(err1, rows) {
            if(err1){
                console.log("Error!!!!");
                throw err1;
            }
            else{
                
                   if(result)
                   {
                        const updated_email = await dbo.collection("Users").updateOne({'Email': current_email}, { $set: {'Email': new_email} });
                        console.log("Change your account email address!!!!");
                        const result1 = await dbo.collection("Users").findOne({'Email': new_email}, {projection: {_id: 0, Username: 1, Password: 1, Email: 1, uuid: 1}}); 
                        console.log(result1);

                        res.render("view_profile");
                    }
                    else
                    {
                        console.log("This user does not exist or has not logged in!!!!");
                    }  
                   
                    
                }

            db.close();
        }); 
        
        
    }

  });

});

app.get("/", function(req, res) {
    res.render('register');});

const username = generateUsername();
app.post("/Register", function(req, res) {
    var new_username = username;
    var new_password = req.body.password;
    var new_email= req.body.email;


    MongoClient.connect(url, async function(err, db){
    if(err){
        console.log("Mongodb connection was a failure!!!!");throw err;
    }
    else{
        console.log("Successfully connected to Mongodb!!!!");
        var dbo = db.db("Navigators");
        var query = {'Username': new_username, 'Password': new_password, 'Email': new_email, 'uuid': ""};
        const result = await dbo.collection("Users").findOne({'Email': new_email}, {projection: {_id: 1, Username: 1, Password: 1, Email: 1}}); 
        
        dbo.collection("Users").find({'Email': new_email}).toArray(function(err1) {
            if(err1){
                console.log("Error!!!!");
                throw err1;
            }
            else{
                
                   if(result)
                   {
                        console.log("This user already exists!!!!");
                    }
                    else
                    {

                        dbo.collection("Users").insertOne(query, {projection: {_id: 0, Username: 1, Password: 1, Email: 1}}, function(err2) {
                            if (err2) throw err2;
                            console.log("The user "+ username + " was registered successfully!!!!");
                            dbo.collection("Users").find({'Email': new_email}).toArray(async function(err3, total) {
                                if(err3){
                                    console.log("Error!!!!");
                                    throw err3;
                                }
                                else{
                                    console.log(total);
                                    res.render("login");
                                }
                            });
                    });  
                   
                    
                }

           }
    });
        
        
    }

  });

});

app.get("/", function(req, res) {
    res.render('destination_review');}
    );

app.post("/Review", upload.single('imagefile'), function(req, res) {
    var myuuid = req.body.uuid;
    var mycomments = req.body.comments;
    var image = JSON.stringify(req.file);
    var newimage = image.toString();

    MongoClient.connect(url, async function(err, db){
    if(err){
        console.log("Mongodb connection was a failure!!!!");throw err;
    }
    else{
        console.log("Successfully connected to Mongodb!!!!");
        var dbo = db.db("Navigators");
        var query = {'uuid': myuuid};
        const result = await dbo.collection("Users").findOne(query, {projection: {_id: 0, Username: 1, Password: 1, Email: 1, uuid: 1}}); 
        
        dbo.collection("Users").find(query).toArray(async function(err1, rows) {
            if(err1){
                console.log("Error!!!!");
                throw err1;
            }
            else{
                
                   if(result)
                   {
                        const comment_update = await dbo.collection("Users").updateOne(query, {$set: {'Comments': mycomments, "Image": newimage}});
                        console.log("User was found!!!!");
                        console.log(comment_update);
                        res.render("destination_info");
                    }
                    else
                    {
                        console.log("This user does not exist or has not logged in!!!!");
                    }  
                   
                    
                }

            db.close();
        }); 
        
        
    }

  });

});

app.get("/", function(req, res) {
    res.render('adminlogin');}
    );

app.post("/LoginAdmin", function(req, res) {
    var myusername = req.body.username;
    var mypassword = req.body.password;
    var myemail= req.body.email;
    var myuuid = req.body.id;


    MongoClient.connect(url, async function(err, db){
    if(err){
        console.log("Mongodb connection was a failure!!!!");throw err;
    }
    else{
        console.log("Successfully connected to Mongodb!!!!");
        var dbo = db.db("Navigators");
        var query = {'Username': myusername, 'Password': mypassword, 'Email': myemail, 'Unique_ID': myuuid};
        const result = await dbo.collection("Administrator").findOne(query, {projection: {_id: 0, Username: 1, Password: 1, Email: 1}}); 
        
        dbo.collection("Administrator").find(query).toArray(async function(err1, rows) {
            if(err1){
                console.log("Error!!!!");
                throw err1;
            }
            else{
                
                   if(result)
                   {
                        console.log("You have successfully logged in admin!!!!");
                        res.render("admin_starting_page");
                    }

                    
                    else
                    {
                        console.log("Invalid credentials!!!!");
                    }  
                   
                    
                }

            db.close();
        }); 
        
        
    }

  });

});

app.get("/redirect_editprofiles", function(req, res) {

    MongoClient.connect(url, async function(err, db){
    if(err){
        console.log("Mongodb connection was a failure!!!!");throw err;
    }
    else{
        console.log("Successfully connected to Mongodb!!!!");
        var dbo = db.db("Navigators");
        const result = await dbo.collection("Users").find({}); 
        
        dbo.collection("Users").find({}).toArray(async function(err1, rows) {
            if(err1){
                console.log("Error!!!!");
                throw err1;
            }
            else{
                
                   if(result)
                   {
                        console.log("There are users that are registered in the mongodb database!!!!");
                        console.log(rows);
                        res.render("edit_profile", {data:rows});
                        
                    }
                    else
                    {
                        console.log("There aren't any users that have been registered!!!!");
                    }  
                   
                    
                }

            db.close();
        }); 
        
        
    }

  });

});

app.get("/", function(req, res) {
    res.render('admin_change_username');}
    );

app.post("/UpdateUsername", function(req, res) {

    var uuid = req.body.uuid;
    var new_username = req.body.new_username;
    
        MongoClient.connect(url, async function(err, db){
        if(err){
            console.log("Mongodb connection was a failure!!!!");throw err;
        }
        else{
            console.log("Successfully connected to Mongodb!!!!");
            var dbo = db.db("Navigators");
            var query = {'uuid': uuid};
            const result = await dbo.collection("Users").findOne(query, {projection: {_id: 0, Username: 1, Password: 1, Email: 1, uuid: 1}}); 
            
            dbo.collection("Users").find(query).toArray(async function(err1, rows) {
                if(err1){
                    console.log("Error!!!!");
                    throw err1;
                }
                else{
                    
                       if(result)
                       {
                            const updated_email = await dbo.collection("Users").updateOne({'uuid': uuid}, { $set: {'Username': new_username} });
                            console.log("Change username!!!!");
                            const result1 = await dbo.collection("Users").findOne({'Username': new_username}, {projection: {_id: 0, Username: 1, Password: 1, Email: 1, uuid: 1}}); 
                            console.log(result1);
                            res.render("admin_starting_page");
                        }
                        else
                        {
                            console.log("This user does not exist or has not logged in!!!!");
                        }  
                       
                        
                    }
    
                db.close();
            }); 
            
            
        }
    
      });
    
    });

    app.get("/", function(req, res) {
        res.render('admin_change_password');}
        );
    
    app.post("/UpdatePassword", function(req, res) {
    
        var uuid = req.body.uuid;
        var new_password = req.body.new_password;
        
            MongoClient.connect(url, async function(err, db){
            if(err){
                console.log("Mongodb connection was a failure!!!!");throw err;
            }
            else{
                console.log("Successfully connected to Mongodb!!!!");
                var dbo = db.db("Navigators");
                var query = {'uuid': uuid};
                const result = await dbo.collection("Users").findOne(query, {projection: {_id: 0, Username: 1, Password: 1, Email: 1, uuid: 1}}); 
                
                dbo.collection("Users").find(query).toArray(async function(err1, rows) {
                    if(err1){
                        console.log("Error!!!!");
                        throw err1;
                    }
                    else{
                        
                           if(result)
                           {
                                const updated_email = await dbo.collection("Users").updateOne({'uuid': uuid}, { $set: {'Password': new_password} });
                                console.log("Change password!!!!");
                                const result1 = await dbo.collection("Users").findOne({'Password': new_password}, {projection: {_id: 0, Username: 1, Password: 1, Email: 1, uuid: 1}}); 
                                console.log(result1);
                                res.render("admin_starting_page");
                            }
                            else
                            {
                                console.log("This user does not exist or has not logged in!!!!");
                            }  
                           
                            
                        }
        
                    db.close();
                }); 
                
                
            }
        
          });
        
        });

        app.get("/", function(req, res) {
            res.render('admin_change_email');}
            );
        
        app.post("/UpdateEmail", function(req, res) {
        
            var uuid = req.body.uuid;
            var new_email = req.body.new_email;
            
                MongoClient.connect(url, async function(err, db){
                if(err){
                    console.log("Mongodb connection was a failure!!!!");throw err;
                }
                else{
                    console.log("Successfully connected to Mongodb!!!!");
                    var dbo = db.db("Navigators");
                    var query = {'uuid': uuid};
                    const result = await dbo.collection("Users").findOne(query, {projection: {_id: 0, Username: 1, Password: 1, Email: 1, uuid: 1}}); 
                    
                    dbo.collection("Users").find(query).toArray(async function(err1, rows) {
                        if(err1){
                            console.log("Error!!!!");
                            throw err1;
                        }
                        else{
                            
                               if(result)
                               {
                                    const updated_email = await dbo.collection("Users").updateOne({'uuid': uuid}, { $set: {'Email': new_email} });
                                    console.log("Change username!!!!");
                                    const result1 = await dbo.collection("Users").findOne({'Email': new_email}, {projection: {_id: 0, Username: 1, Password: 1, Email: 1, uuid: 1}}); 
                                    console.log(result1);
                                    res.render("admin_starting_page");
                                }
                                else
                                {
                                    console.log("This user does not exist or has not logged in!!!!");
                                }  
                               
                                
                            }
            
                        db.close();
                    }); 
                    
                    
                }
            
              });
            
            });


            app.get("/", function(req, res) {
                res.render('admin_change_uuid');}
                );
            
            app.post("/UpdateUuid", function(req, res) {
            
                var uuid = req.body.uuid;
                var new_uuid = req.body.new_uuid;
                
                    MongoClient.connect(url, async function(err, db){
                    if(err){
                        console.log("Mongodb connection was a failure!!!!");throw err;
                    }
                    else{
                        console.log("Successfully connected to Mongodb!!!!");
                        var dbo = db.db("Navigators");
                        var query = {'uuid': uuid};
                        const result = await dbo.collection("Users").findOne(query, {projection: {_id: 0, Username: 1, Password: 1, Email: 1, uuid: 1}}); 
                        
                        dbo.collection("Users").find(query).toArray(async function(err1, rows) {
                            if(err1){
                                console.log("Error!!!!");
                                throw err1;
                            }
                            else{
                                
                                   if(result)
                                   {
                                        const updated_email = await dbo.collection("Users").updateOne({'uuid': uuid}, { $set: {'uuid': new_uuid} });
                                        console.log("Change username!!!!");
                                        const result1 = await dbo.collection("Users").findOne({'uuid': new_uuid}, {projection: {_id: 0, Username: 1, Password: 1, Email: 1, uuid: 1}}); 
                                        console.log(result1);
                                        res.render("admin_starting_page");
                                    }
                                    else
                                    {
                                        console.log("This user does not exist or has not logged in!!!!");
                                    }  
                                   
                                    
                                }
                
                            db.close();
                        }); 
                        
                        
                    }
                
                  });
                
                });

                app.get("/", function(req, res) {
                    res.render('admin_change_comments');}
                    );
                
                app.post("/UpdateComments", function(req, res) {
                
                    var uuid = req.body.uuid;
                    var new_comments = req.body.new_comments;
                    
                        MongoClient.connect(url, async function(err, db){
                        if(err){
                            console.log("Mongodb connection was a failure!!!!");throw err;
                        }
                        else{
                            console.log("Successfully connected to Mongodb!!!!");
                            var dbo = db.db("Navigators");
                            var query = {'uuid': uuid};
                            const result = await dbo.collection("Users").findOne(query, {projection: {_id: 0, Username: 1, Password: 1, Email: 1, uuid: 1}}); 
                            
                            dbo.collection("Users").find(query).toArray(async function(err1, rows) {
                                if(err1){
                                    console.log("Error!!!!");
                                    throw err1;
                                }
                                else{
                                    
                                       if(result)
                                       {
                                            const updated_email = await dbo.collection("Users").updateOne({'uuid': uuid}, { $set: {'Comments': new_comments} });
                                            console.log("Change comments!!!!");
                                            const result1 = await dbo.collection("Users").findOne({'Comments': new_comments}, {projection: {_id: 0, Username: 1, Password: 1, Email: 1, uuid: 1}}); 
                                            console.log(result1);
                                            res.render("admin_starting_page");
                                        }
                                        else
                                        {
                                            console.log("This user does not exist or has not logged in!!!!");
                                        }  
                                       
                                        
                                    }
                    
                                db.close();
                            }); 
                            
                            
                        }
                    
                      });
                    
                    });


                    app.get("/", function(req, res) {
                        res.render('admin_remove_user');}
                        );
                    
                    app.post("/DeleteUser", function(req, res) {
                    
                        var uuid = req.body.uuid;
                        
                            MongoClient.connect(url, async function(err, db){
                            if(err){
                                console.log("Mongodb connection was a failure!!!!");throw err;
                            }
                            else{
                                console.log("Successfully connected to Mongodb!!!!");
                                var dbo = db.db("Navigators");
                                var query = {'uuid': uuid};
                                const result = await dbo.collection("Users").findOne(query, {projection: {_id: 0, Username: 1, Password: 1, Email: 1, uuid: 1}}); 
                                
                                dbo.collection("Users").find(query).toArray(async function(err1, rows) {
                                    if(err1){
                                        console.log("Error!!!!");
                                        throw err1;
                                    }
                                    else{
                                        
                                           if(result)
                                           {
                                                const updated_email = await dbo.collection("Users").deleteOne({'uuid': uuid});
                                                console.log("Change comments!!!!");
                                                const result1 = await dbo.collection("Users").findOne({'uuid': uuid}, {projection: {_id: 0, Username: 1, Password: 1, Email: 1, uuid: 1}}); 
                                                console.log(result1);
                                                res.render("admin_starting_page");
                                            }
                                            else
                                            {
                                                console.log("This user does not exist or has not logged in!!!!");
                                            }  
                                           
                                            
                                        }
                        
                                    db.close();
                                }); 
                                
                                
                            }
                        
                          });
                        
                        });

app.get("/redirect_change_destination", function(req, res) {
    res.render('edit_destination');})

app.get("/redirect_booking", function(req, res) {
    res.render('booking_page');}
    );

app.get("/", function(req, res) {
    res.render('booking_page');}
    );

app.post("/Book", function(req, res) {
    
    var checkin = req.body.checkin;
    var checkin2 = new Date();
    var checkin3 = checkin2.toISOString();
    var checkout = req.body.checkout;
    var checkout2 = new Date();
    var checkout3 = checkout2.toISOString();
    var count = req.body.quantity;
    var total_cost  = req.body.tcost;
    var days = req.body.days;
    var radio = req.body.radio;
    var randid = req.body.random;
    var uuid = req.body.uuid;
    var card1 = req.body.part1;
    var card2 = req.body.part2;
    var card3 = req.body.part3;
    var card4 = req.body.part4;

    var rand = Math.floor(Math.random() * 10000) + 90000;
    console.log(rand);

    MongoClient.connect(url, async function(err, db){
        if(err){
            console.log("Mongodb connection was a failure!!!!");throw err;
        }
        else{
            console.log("Successfully connected to Mongodb!!!!");
            var dbo = db.db("Navigators");
            var query = {"uuid":uuid};
            const result = await dbo.collection("Booking").findOne(query, {projection: {_id: 0, uuid: 1}});

            dbo.collection("Booking").find(query).toArray(async function(err1, rows) {
                if(err1){
                    console.log("Error!!!!");
                    throw err1;
                }
                else{
                    
                       if(result)
                       {
                            var wallet1 = await dbo.collection("Booking").findOne({"uuid": uuid});
                            wallet = rows[0].Wallet;
                            remaining = wallet - parseInt(total_cost);
                            if ((remaining >= 0) && (10000 == randid) && ((radio == "Debit") || (radio == "Credit")))
                            {
                                    
                                const book =  await dbo.collection("Booking").updateOne({'uuid': uuid}, { $set: {'Wallet': remaining, "Date_In": checkin, "Date_Out":checkout, "Count": count, "Radio": radio, "Card_Code1": card1, "Card_Code2": card2, "Card_Code3": card3, "Card_Code4": card4, "Days": days, "Random_Id": parseInt(randid)}});
                                console.log("               <<Receipt>>");
                                console.log("-------------------------------------------");
                                console.log(book);
                                console.log("Total_Cost:"+total_cost+"$");
                                console.log("")
                                res.render('starting_page'); 
                            }
                            
                            else
                            {
                                console.log("The user does not have enough money to purchase the corresponding ticket or has not entered the correct card type!!!!");
                            }
                        }
                        else
                        {
                            console.log("This user does not exist or has not logged in!!!!");
                        }  
                       
                        
                    }
    
                db.close();
            }); 


        }
    });

});

    
app.get("/redirect_editbooking", function(req, res) {

    MongoClient.connect(url, async function(err, db){
    if(err){
        console.log("Mongodb connection was a failure!!!!");throw err;
    }
    else{
        console.log("Successfully connected to Mongodb!!!!");
        var dbo = db.db("Navigators");
        const result = await dbo.collection("Booking").find({}); 
        
        dbo.collection("Booking").find({}).toArray(async function(err1, rows) {
            if(err1){
                console.log("Error!!!!");
                throw err1;
            }
            else{
                
                   if(result)
                   {
                        console.log("There are users that have booked tickets in the mongodb database!!!!");
                        console.log(rows);
                        res.render("edit_booking_page", {data:rows});
                        
                    }
                    else
                    {
                        console.log("There aren't any users that have booked any tickets!!!");
                    }  
                   
                    
                }

            db.close();
        }); 
        
        
    }

  });

});

        
app.get("/", function(req, res) {
    res.render('admin_booking_uuid');}
    );

app.post("/UpdateBookingUuid", function(req, res) {

    var uuid = req.body.uuid;
    var new_uuid = req.body.new_uuid;
    
        MongoClient.connect(url, async function(err, db){
        if(err){
            console.log("Mongodb connection was a failure!!!!");throw err;
        }
        else{
            console.log("Successfully connected to Mongodb!!!!");
            var dbo = db.db("Navigators");
            var query = {'uuid': uuid};
            const result = await dbo.collection("Booking").findOne(query); 
            
            dbo.collection("Booking").find(query).toArray(async function(err1, rows) {
                if(err1){
                    console.log("Error!!!!");
                    throw err1;
                }
                else{
                    
                       if(result)
                       {
                            const updated_uuid = await dbo.collection("Booking").updateOne({'uuid': uuid}, { $set: {'uuid': new_uuid} });
                            console.log("Change uuid!!!!");
                            console.log(updated_uuid);
                            res.render("admin_starting_page");
                        }
                        else
                        {
                            console.log("This user does not exist or has not logged in!!!!");
                        }  
                       
                        
                    }
    
                db.close();
            }); 
            
            
        }
    
      });
    
    });

    app.get("/", function(req, res) {
        res.render('admin_booking_checkin');}
        );
    
    app.post("/UpdateBookingCheckIn", function(req, res) {
    
        var checkin = req.body.checkin;
        var new_checkin = req.body.new_checkin;
        
            MongoClient.connect(url, async function(err, db){
            if(err){
                console.log("Mongodb connection was a failure!!!!");throw err;
            }
            else{
                console.log("Successfully connected to Mongodb!!!!");
                var dbo = db.db("Navigators");
                var query = {'Date_In': checkin};
                const result = await dbo.collection("Booking").findOne(query); 
                
                dbo.collection("Booking").find(query).toArray(async function(err1, rows) {
                    if(err1){
                        console.log("Error!!!!");
                        throw err1;
                    }
                    else{
                        
                           if(result)
                           {
                                const updated_checkin = await dbo.collection("Booking").updateOne({'Date_In': checkin}, { $set: {'Date_In': new_checkin} });
                                console.log("Change checkin date!!!!");
                                console.log(updated_checkin);
                                res.render("admin_starting_page");
                            }
                            else
                            {
                                console.log("This user does not exist or has not logged in!!!!");
                            }  
                           
                            
                        }
        
                    db.close();
                }); 
                
                
            }
        
          });
        
        });


        app.get("/", function(req, res) {
            res.render('admin_booking_checkout');}
            );
        
        app.post("/UpdateBookingCheckOut", function(req, res) {
        
            var checkout = req.body.checkout;
            var new_checkout = req.body.new_checkout;
            
                MongoClient.connect(url, async function(err, db){
                if(err){
                    console.log("Mongodb connection was a failure!!!!");throw err;
                }
                else{
                    console.log("Successfully connected to Mongodb!!!!");
                    var dbo = db.db("Navigators");
                    var query = {'Date_Out': checkout};
                    const result = await dbo.collection("Booking").findOne(query); 
                    
                    dbo.collection("Booking").find(query).toArray(async function(err1, rows) {
                        if(err1){
                            console.log("Error!!!!");
                            throw err1;
                        }
                        else{
                            
                               if(result)
                               {
                                    const updated_checkout = await dbo.collection("Booking").updateOne({'Date_Out': checkout}, { $set: {'Date_Out': new_checkout} });
                                    console.log("Change checkout date!!!!");
                                    console.log(updated_checkout);
                                    res.render("admin_starting_page");
                                }
                                else
                                {
                                    console.log("This user does not exist or has not logged in!!!!");
                                }  
                               
                                
                            }
            
                        db.close();
                    }); 
                    
                    
                }
            
              });
            
            });

            app.get("/", function(req, res) {
                res.render('admin_booking_count');}
                );
            
            app.post("/UpdateBookingCount", function(req, res) {
            
                var count = req.body.count;
                var new_count = req.body.new_count;
                
                    MongoClient.connect(url, async function(err, db){
                    if(err){
                        console.log("Mongodb connection was a failure!!!!");throw err;
                    }
                    else{
                        console.log("Successfully connected to Mongodb!!!!");
                        var dbo = db.db("Navigators");
                        var query = {'Count': count};
                        const result = await dbo.collection("Booking").findOne(query); 
                        
                        dbo.collection("Booking").find(query).toArray(async function(err1, rows) {
                            if(err1){
                                console.log("Error!!!!");
                                throw err1;
                            }
                            else{
                                
                                   if(result)
                                   {
                                        const updated_count = await dbo.collection("Booking").updateOne({'Count': count}, { $set: {'Count': new_count} });
                                        console.log("Change count of people!!!!");
                                        console.log(updated_count);
                                        res.render("admin_starting_page");
                                    }
                                    else
                                    {
                                        console.log("This user does not exist or has not logged in!!!!");
                                    }  
                                   
                                    
                                }
                
                            db.close();
                        }); 
                        
                        
                    }
                
                  });
                
                });

                app.get("/", function(req, res) {
                    res.render('admin_booking_code1');}
                    );
                
                app.post("/UpdateBookingCode1", function(req, res) {
                
                    var code1 = req.body.part1;
                    var new_code1 = req.body.new_part1;
                    
                        MongoClient.connect(url, async function(err, db){
                        if(err){
                            console.log("Mongodb connection was a failure!!!!");throw err;
                        }
                        else{
                            console.log("Successfully connected to Mongodb!!!!");
                            var dbo = db.db("Navigators");
                            var query = {'Card_Code1': code1};
                            const result = await dbo.collection("Booking").findOne(query); 
                            
                            dbo.collection("Booking").find(query).toArray(async function(err1, rows) {
                                if(err1){
                                    console.log("Error!!!!");
                                    throw err1;
                                }
                                else{
                                    
                                       if(result)
                                       {
                                            const updated_code1 = await dbo.collection("Booking").updateOne({'Card_Code1': code1}, { $set: {'Card_Code1': new_code1} });
                                            console.log("Change 16-digit code part1!!!!");
                                            console.log(updated_code1);
                                            res.render("admin_starting_page");
                                        }
                                        else
                                        {
                                            console.log("This user does not exist or has not logged in!!!!");
                                        }  
                                       
                                        
                                    }
                    
                                db.close();
                            }); 
                            
                            
                        }
                    
                      });
                    
                    });

                    app.get("/", function(req, res) {
                        res.render('admin_booking_code2');}
                        );
                    
                    app.post("/UpdateBookingCode2", function(req, res) {
                    
                        var code2 = req.body.part2;
                        var new_code2 = req.body.new_part2;
                        
                            MongoClient.connect(url, async function(err, db){
                            if(err){
                                console.log("Mongodb connection was a failure!!!!");throw err;
                            }
                            else{
                                console.log("Successfully connected to Mongodb!!!!");
                                var dbo = db.db("Navigators");
                                var query = {'Card_Code2': code2};
                                const result = await dbo.collection("Booking").findOne(query); 
                                
                                dbo.collection("Booking").find(query).toArray(async function(err1, rows) {
                                    if(err1){
                                        console.log("Error!!!!");
                                        throw err1;
                                    }
                                    else{
                                        
                                           if(result)
                                           {
                                                const updated_code2 = await dbo.collection("Booking").updateOne({'Card_Code2': code2}, { $set: {'Card_Code2': new_code2} });
                                                console.log("Change 16-digit code part2!!!!");
                                                console.log(updated_code2);
                                                res.render("admin_starting_page");
                                            }
                                            else
                                            {
                                                console.log("This user does not exist or has not logged in!!!!");
                                            }  
                                           
                                            
                                        }
                        
                                    db.close();
                                }); 
                                
                                
                            }
                        
                          });
                        
                        });

                        app.get("/", function(req, res) {
                            res.render('admin_booking_code3');}
                            );
                        
                        app.post("/UpdateBookingCode3", function(req, res) {
                        
                            var code3 = req.body.part3;
                            var new_code3 = req.body.new_part3;
                            
                                MongoClient.connect(url, async function(err, db){
                                if(err){
                                    console.log("Mongodb connection was a failure!!!!");throw err;
                                }
                                else{
                                    console.log("Successfully connected to Mongodb!!!!");
                                    var dbo = db.db("Navigators");
                                    var query = {'Card_Code3': code3};
                                    const result = await dbo.collection("Booking").findOne(query); 
                                    
                                    dbo.collection("Booking").find(query).toArray(async function(err1, rows) {
                                        if(err1){
                                            console.log("Error!!!!");
                                            throw err1;
                                        }
                                        else{
                                            
                                               if(result)
                                               {
                                                    const updated_code3 = await dbo.collection("Booking").updateOne({'Card_Code3': code3}, { $set: {'Card_Code3': new_code3} });
                                                    console.log("Change 16-digit code part3!!!!");
                                                    console.log(updated_code3);
                                                    res.render("admin_starting_page");
                                                }
                                                else
                                                {
                                                    console.log("This user does not exist or has not logged in!!!!");
                                                }  
                                               
                                                
                                            }
                            
                                        db.close();
                                    }); 
                                    
                                    
                                }
                            
                              });
                            
                            });

                            app.get("/", function(req, res) {
                                res.render('admin_booking_code4');}
                                );
                            
                            app.post("/UpdateBookingCode4", function(req, res) {
                            
                                var code4 = req.body.part4;
                                var new_code4 = req.body.new_part4;
                                
                                    MongoClient.connect(url, async function(err, db){
                                    if(err){
                                        console.log("Mongodb connection was a failure!!!!");throw err;
                                    }
                                    else{
                                        console.log("Successfully connected to Mongodb!!!!");
                                        var dbo = db.db("Navigators");
                                        var query = {'Card_Code4': code4};
                                        const result = await dbo.collection("Booking").findOne(query); 
                                        
                                        dbo.collection("Booking").find(query).toArray(async function(err1, rows) {
                                            if(err1){
                                                console.log("Error!!!!");
                                                throw err1;
                                            }
                                            else{
                                                
                                                   if(result)
                                                   {
                                                        const updated_code4 = await dbo.collection("Booking").updateOne({'Card_Code4': code4}, { $set: {'Card_Code4': new_code4} });
                                                        console.log("Change 16-digit code part4!!!!");
                                                        console.log(updated_code4);
                                                        res.render("admin_starting_page");
                                                    }
                                                    else
                                                    {
                                                        console.log("This user does not exist or has not logged in!!!!");
                                                    }  
                                                   
                                                    
                                                }
                                
                                            db.close();
                                        }); 
                                        
                                        
                                    }
                                
                                  });
                                
                                });

                                app.get("/", function(req, res) {
                                    res.render('admin_booking_days');}
                                    );
                                
                                app.post("/UpdateBookingDays", function(req, res) {
                                
                                    var days = req.body.days;
                                    var new_days = req.body.new_days;
                                    
                                        MongoClient.connect(url, async function(err, db){
                                        if(err){
                                            console.log("Mongodb connection was a failure!!!!");throw err;
                                        }
                                        else{
                                            console.log("Successfully connected to Mongodb!!!!");
                                            var dbo = db.db("Navigators");
                                            var query = {'Days': days};
                                            const result = await dbo.collection("Booking").findOne(query); 
                                            
                                            dbo.collection("Booking").find(query).toArray(async function(err1, rows) {
                                                if(err1){
                                                    console.log("Error!!!!");
                                                    throw err1;
                                                }
                                                else{
                                                    
                                                       if(result)
                                                       {
                                                            const updated_days = await dbo.collection("Booking").updateOne({'Days': days}, { $set: {'Days': new_days} });
                                                            console.log("Change staying days!!!!");
                                                            console.log(updated_days);
                                                            res.render("admin_starting_page");
                                                        }
                                                        else
                                                        {
                                                            console.log("This user does not exist or has not logged in!!!!");
                                                        }  
                                                       
                                                        
                                                    }
                                    
                                                db.close();
                                            }); 
                                            
                                            
                                        }
                                    
                                      });
                                    
                                    });

                                    app.get("/", function(req, res) {
                                        res.render('admin_booking_radio');}
                                        );
                                    
                                    app.post("/UpdateBookingRadio", function(req, res) {
                                    
                                        var radio = req.body.radio;
                                        var new_radio = req.body.new_radio;
                                        
                                            MongoClient.connect(url, async function(err, db){
                                            if(err){
                                                console.log("Mongodb connection was a failure!!!!");throw err;
                                            }
                                            else{
                                                console.log("Successfully connected to Mongodb!!!!");
                                                var dbo = db.db("Navigators");
                                                var query = {'Radio': radio};
                                                const result = await dbo.collection("Booking").findOne(query); 
                                                
                                                dbo.collection("Booking").find(query).toArray(async function(err1, rows) {
                                                    if(err1){
                                                        console.log("Error!!!!");
                                                        throw err1;
                                                    }
                                                    else{
                                                        
                                                           if(result)
                                                           {
                                                                const updated_radio = await dbo.collection("Booking").updateOne({'Radio': radio}, { $set: {'Radio': new_radio} });
                                                                console.log("Change card type!!!!");
                                                                console.log(updated_radio);
                                                                res.render("admin_starting_page");
                                                            }
                                                              
                                                            else
                                                            {
                                                                console.log("This user does not exist or has not logged in!!!!");
                                                            }  
                                                           
                                                            
                                                        }
                                        
                                                    db.close();
                                                }); 
                                                
                                                
                                            }
                                        
                                          });
                                        
                                        });

                                        app.get("/", function(req, res) {
                                            res.render('admin_booking_wallet');}
                                            );
                                        
                                        app.post("/UpdateBookingWallet", function(req, res) {
                                        
                                            var wallet = req.body.wallet;
                                            var new_wallet = req.body.new_wallet;
                                            
                                                MongoClient.connect(url, async function(err, db){
                                                if(err){
                                                    console.log("Mongodb connection was a failure!!!!");throw err;
                                                }
                                                else{
                                                    console.log("Successfully connected to Mongodb!!!!");
                                                    var dbo = db.db("Navigators");
                                                    var query = {'Wallet': parseInt(wallet)};
                                                    const result = await dbo.collection("Booking").findOne(query); 
                                                    
                                                    dbo.collection("Booking").find(query).toArray(async function(err1, rows) {
                                                        if(err1){
                                                            console.log("Error!!!!");
                                                            throw err1;
                                                        }
                                                        else{
                                                            
                                                               if(result)
                                                               {
                                                                    const updated_wallet = await dbo.collection("Booking").updateOne({'Wallet': parseInt(wallet)}, { $set: {'Wallet': parseInt(new_wallet)} });
                                                                    console.log("Change wallet money!!!!");
                                                                    console.log(updated_wallet);
                                                                    res.render("admin_starting_page");
                                                                }
                                                                else
                                                                {
                                                                    console.log("This user does not exist or has not logged in!!!!");
                                                                }  
                                                               
                                                                
                                                            }
                                            
                                                        db.close();
                                                    }); 
                                                    
                                                    
                                                }
                                            
                                              });
                                            
                                            });

                                            app.get("/", function(req, res) {
                                                res.render('admin_booking_randomcode');}
                                                );
                                            
                                            app.post("/UpdateBookingRandomCode", function(req, res) {
                                            
                                                var randomid = req.body.randomid;
                                                var new_randomid = req.body.new_randomid;
                                                
                                                    MongoClient.connect(url, async function(err, db){
                                                    if(err){
                                                        console.log("Mongodb connection was a failure!!!!");throw err;
                                                    }
                                                    else{
                                                        console.log("Successfully connected to Mongodb!!!!");
                                                        var dbo = db.db("Navigators");
                                                        var query = {'Random_Id': parseInt(randomid)};
                                                        const result = await dbo.collection("Booking").findOne(query); 
                                                        
                                                        dbo.collection("Booking").find(query).toArray(async function(err1, rows) {
                                                            if(err1){
                                                                console.log("Error!!!!");
                                                                throw err1;
                                                            }
                                                            else{
                                                                
                                                                   if(result)
                                                                   {
                                                                        const updated_randomid = await dbo.collection("Booking").updateOne({'Random_Id': parseInt(randomid)}, { $set: {'Random_Id': parseInt(new_randomid)} });
                                                                        console.log("Change random code!!!!");
                                                                        console.log(updated_randomid);
                                                                        res.render("admin_starting_page");
                                                                    }
                                                                    else
                                                                    {
                                                                        console.log("This user does not exist or has not logged in!!!!");
                                                                    }  
                                                                   
                                                                    
                                                                }
                                                
                                                            db.close();
                                                        }); 
                                                        
                                                        
                                                    }
                                                
                                                  });
                                                
                                                });



                                                app.get("/", function(req, res) {
                                                    res.render('admin_remove_booking');}
                                                    );
                                                
                                                app.post("/DeleteBooking", function(req, res) {
                                                
                                                    var uuid = req.body.uuid;
                                                    
                                                        MongoClient.connect(url, async function(err, db){
                                                        if(err){
                                                            console.log("Mongodb connection was a failure!!!!");throw err;
                                                        }
                                                        else{
                                                            console.log("Successfully connected to Mongodb!!!!");
                                                            var dbo = db.db("Navigators");
                                                            var query = {'uuid': uuid};
                                                            const result = await dbo.collection("Booking").findOne(query); 
                                                            
                                                            dbo.collection("Booking").find(query).toArray(async function(err1, rows) {
                                                                if(err1){
                                                                    console.log("Error!!!!");
                                                                    throw err1;
                                                                }
                                                                else{
                                                                    
                                                                       if(result)
                                                                       {
                                                                            const updated_booking = await dbo.collection("Booking").deleteOne({'uuid': uuid});
                                                                            console.log("Remove Booking!!!!");
                                                                            console.log(updated_booking);
                                                                            res.render("admin_starting_page");
                                                                        }
                                                                        else
                                                                        {
                                                                            console.log("This user does not exist or has not logged in!!!!");
                                                                        }  
                                                                       
                                                                        
                                                                    }
                                                    
                                                                db.close();
                                                            }); 
                                                            
                                                            
                                                        }
                                                    
                                                      });
                                                    
                                                    });
                
            
        
                                            

    