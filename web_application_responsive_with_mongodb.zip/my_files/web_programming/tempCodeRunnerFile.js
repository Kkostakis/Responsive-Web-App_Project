app.get("/redirect", function(req, res) {
    res.render('starting_page');}
    );